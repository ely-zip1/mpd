<div class="hero align-items-center bg-success text-white">
  <div class="hero-inner text-center">
    <h2>Congratulations</h2>
    <p class="lead">You have successfully registered with our system. Next, you can log in to the dashboard with your account.</p>
    <div class="mt-4">
      <a href="logout" class="btn btn-outline-white btn-lg btn-icon icon-left"><i class="fas fa-sign-in-alt"></i> Login</a>
    </div>
  </div>
</div>
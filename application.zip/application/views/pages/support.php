<div class="main-content">
	<section class="section">
		<div class="section-header">
            <h1>Support</h1> 
        </div>
		<div class="container mt-5">
			<div class="row">
				<div class="col-12 col-sm-8 offset-sm-2 ">
					<div class="login-brand">
                        <h2 class="text-center">MP Diamonds Support</h2> 
                    </div>
					<div class="card">
						<div class="card-body">
                            <p class="text-center">For inquiries, suggestions, and complaints, email us at</p>
                            <p class="text-center text-monospace">mpdiamonds2020@gmail.com</p>
                        </div>
						<div class="footer"> </div>
					</div>
				</div>
			</div>
		</div>
	</section>
</div>
<div class="main-content">
<section class="section">
		<div class="section-header">
			<h1>Choose a Plan</h1> </div>
		<div class="container mt-5">
			<div class="row">
            <div class="col-12 col-md-4 col-lg-4">
                <div class="card">
                  <img class="card-img" src="<?= base_url();?>assets/img/yellow.png" alt="Card image">
                  <div class="card-footer text-center bg-dark">
                    <a class="text-white" href="<?= base_url()?>PayKnight">Deposit <i class="fas fa-arrow-right"></i></a>
                  </div>
                </div>
            </div>
            
            <div class="col-12 col-md-4 col-lg-4">
                <div class="card">
                  <img class="card-img" src="<?= base_url();?>assets/img/blue.png" alt="Card image">
                  <div class="card-footer text-center bg-dark">
                    <a class="text-white" href="<?= base_url()?>PayTower">Deposit <i class="fas fa-arrow-right"></i></a>
                  </div>
                </div>
            </div>
            
            <div class="col-12 col-md-4 col-lg-4">
                <div class="card">
                  <img class="card-img" src="<?= base_url();?>assets/img/purple.png" alt="Card image">
                  <div class="card-footer text-center bg-dark">
                    <a class="text-white" href="<?= base_url()?>PayQueen">Deposit <i class="fas fa-arrow-right"></i></a>
                  </div>
                </div>
            </div>
            
			</div>
		</div>
	</section>
</div>
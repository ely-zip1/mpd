<div class="main-content">
    <section class="section">
        <div class="section-header">
            <!-- <h1>Update Account</h1>  -->
        </div>
        <div class="container mt-5">
            <!-- <?php print_r($deposit_data);?> -->
            <div class="row">
                <div class="col-12 col-sm-12">
                    <div class="login-brand">
                        <h4>Pending Withdrawals</h4>
                    </div>
                    <div class="card card-info">
                        <div class="card-body">
                            <div class="main-content">
                                <section class="section">
                                    <div class="section-header">
                                        <!-- <h1>Update Account</h1>  -->
                                    </div>
                                    <div class="container mt-5">
                                        <!-- <?php print_r($deposit_data);?> -->
                                        <div class="row">
                                            <div class="col-12 col-sm-12">
                                                <div class="login-brand">
                                                    <h4>Pending Withdrawals</h4>
                                                </div>
                                                <div class="card card-info">
                                                    <div class="card-body">
                                                    
                                                        <div class="form-group row">
                                                            <label for="staticEmail"
                                                                class="col-sm-2 col-form-label">Email</label>
                                                            <div class="col-sm-10">
                                                                <input type="text" readonly
                                                                    class="form-control-plaintext" id="staticEmail"
                                                                    value="email@example.com">
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group row">
                                                            <label for="staticEmail"
                                                                class="col-sm-2 col-form-label">Email</label>
                                                            <div class="col-sm-10">
                                                                <input type="text" readonly
                                                                    class="form-control-plaintext" id="staticEmail"
                                                                    value="email@example.com">
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <div class="footer"> </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
    </section>
</div>


</div>
<div class="footer"> </div>
</div>
</div>
</div>
</div>
</div>
</section>
</div>
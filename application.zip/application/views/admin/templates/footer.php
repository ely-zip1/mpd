<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
</body>
      <!-- <footer class="main-footer">
        <div class="footer-left">
          
        </div>
        <div class="footer-right">

        </div>
      </footer>
    </div>
  </div> -->

<?php $this->load->view('dist/_partials/js'); ?>
<script src="https://kit.fontawesome.com/yourcode.js"></script>
